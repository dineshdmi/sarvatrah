import React from 'react'

const Privacy = () => {
  return (
    <div>Privacy</div>
  )
}

export default Privacy