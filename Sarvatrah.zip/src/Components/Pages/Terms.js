import React from 'react'

const Terms = () => {
  return (
    <div>Terms</div>
  )
}

export default Terms