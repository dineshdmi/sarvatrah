import React from 'react'

const Refund = () => {
  return (
    <div>Refund</div>
  )
}

export default Refund